<div class="navbar">
    <a href="index.php"><i class="fa-solid fa-tachometer-alt"></i> Dashboard</a>
    <a href="registrar_ingreso.php" class="btn-ingreso"><i class="fa-solid fa-plus-circle"></i> Registrar Ingreso</a>
    <a href="registrar_gasto.php" class="btn-gasto"><i class="fa-solid fa-minus-circle"></i> Registrar Gasto</a>
    <!-- Enlaces para ver los ingresos y los gastos -->
    <a href="ver_ingresos.php"><i class="fa-solid fa-money-bill-wave"></i> Ver Ingresos</a>
    <a href="ver_gastos.php"><i class="fa-solid fa-file-invoice"></i> Ver Gastos</a>
    <!-- Agregar el enlace para gestionar deudas -->
    <a href="deudas.php"><i class="fa-solid fa-file-invoice-dollar"></i> Gestionar Deudas</a>
    <a href="logout.php" class="btn-logout"><i class="fa-solid fa-sign-out-alt"></i> Cerrar sesión</a>
</div>
